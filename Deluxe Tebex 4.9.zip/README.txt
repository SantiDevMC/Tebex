Thanks for downloading Deluxe Tebex 4.9!

DOCUMENTATION: https://documentation.triplezone.dev
DISCORD SERVER FOR SUPPORT: https://discord.gg/YTt8GWR

If you come from 4.8 make sure to add the new config options to your config.twig file!