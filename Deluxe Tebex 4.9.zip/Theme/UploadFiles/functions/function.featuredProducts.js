const setFeaturedProducts = () => {
    if (featuredProducts.size < 1) return;
    document.querySelector(".featured__packages").style.display = "block"

    for (const [id, value] of featuredProducts) {

        const packagesContainer = document.querySelector('.featured__packages--flex')
        const { image, color, name, price, discount, discountPercent } = value
        
        const discountPercentage = Math.round(Number(discountPercent))

        const saleAmount = () => "{{ lang.featuredProductSale }}".replace("%amount%", discountPercentage)

        function isColor(str) {
            let colorRegex = /^#([0-9a-fA-F]{3}){1,2}$/;
            return colorRegex.test(str);
        }

        const htmlProduct = `
        <div class="featured__package triplezone__toogle--modal" id="featured__${id}" data-remote="/package/${id}">
            <div class="featured__package--circle">
                <img src="${image}" alt="${name}">
            </div>
            <div class="featured__package--text">
                <p class="featured__package__text--title">${name} 
                    {% if config("displayFeaturedProductSalePercentage") == "enabled" %} 
                        <span class="featured__sale" style="--color: ${isColor(color) ? color : "var(--main-color)"}; ${discountPercentage <= 0 && "display: none;"}">${saleAmount()}</span>
                    {% endif %}
                </p>
                <p class="featured__package__text--price">${discount > 0 ? `<del style="color: var(--error-color); margin-right: 5px;">${discount}</del>` : ""}<span>${price}</span> {{ basket.currency }}</p>
            </div>
        </div>       
        `

        packagesContainer.innerHTML += htmlProduct

        const packageHtml = document.querySelector(`#featured__${id}`)
        const packageTitle = document.querySelector(`#featured__${id} .featured__package__text--title`)
        packageHtml.style.background = `${color}3F`
        packageHtml.style.borderColor = `${color}`
        packageTitle.style.color = `${color}`
    }
}

{% if page.title == "Welcome" %}
setFeaturedProducts()
{% endif %}