function numberWithCommas(number) {
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function getBasket() {
    return $.parseJSON($("#basket_items").text())
}

function updateBasket(element) {
    $("#basket_items").html(element)
}