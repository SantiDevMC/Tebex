const modalProductId = "467750"

$(function () {

    $('.quantity-form').on("submit", function (e) {

        e.preventDefault();

        $(".quantity__item").css("opacity", "0.7")

        $(".qty-count").addClass("disabled__btn")
        $(".quantity__input").addClass("disabled__btn")

        $.ajax({
            url: '/checkout/update',
            data: $(this).serialize(),
            method: 'POST'
        })

            .done(function (resp) {
                let q = $(resp).find("#total-cart")
                let test = $(resp).filter("#basket_items")

                function getUpdatedBasket() {
                    return $.parseJSON(test.text())
                }

                for (let products in getUpdatedBasket()) {
                    let each_product = getUpdatedBasket()[products];
                    $(".cart__ajax--total_price").text(`${each_product.total_basket}`)
                    $(".__total--basket").text(`${each_product.total_basket}`)
                }

                updateBasket(test.text())

                $(".quantity__item").css("opacity", "1")
                $(".qty-count").removeClass("disabled__btn")
                $(".quantity__input").removeClass("disabled__btn")

                $(".minus__indicator").show()
                $(".plus__indicator").show()
                $(".plus__indicator").show()
                $(".__loading--refresh").hide()

            });
    });

    $(".qty-count").on("click", function (event) {

        event.stopPropagation()

        if ($(this).attr("data-action") == "add") {

            // Luam ID de la item pentru a-l compara cu id-ul inputului.
            let dataPackage = $(this).attr("data-package")

            // Construim inputul
            let dataInput = $(`.quantity__input[name="${dataPackage}"]`)

            // Luam valoarea recenta a inputului si o transformam in integer
            let recentValue = parseInt($(dataInput).val())

            $(`.quantity__increase[data-package="${dataPackage}"] .plus__indicator`).hide()
            $(`.quantity__increase[data-package="${dataPackage}"] .__loading--refresh`).css("display", "inline-block")

            // Mareste cantitatea produsului cu 1
            $(dataInput).val(recentValue + 1)

            // Dam submit la form
            $(dataInput).submit()

            return false;

        }

        if ($(this).attr("data-action") == "minus") {

            // Luam ID de la item pentru a-l compara cu id-ul inputului.
            let dataPackage = $(this).attr("data-package")

            // Construim inputul
            let dataInput = $(`.quantity__input[name="${dataPackage}"]`)
            let dataButton = $(`.quantity__decrease[data-package="${dataPackage}"]`)

            // Luam valoarea recenta a inputului si o transformam in integer
            let recentValue = parseInt($(dataInput).val())

            if (recentValue > 1) {

                $(`.quantity__decrease[data-package="${dataPackage}"] .minus__indicator`).hide()
                $(`.quantity__decrease[data-package="${dataPackage}"] .__loading--refresh`).css("display", "inline-block")

                // Scade cantitatea produsului cu 1
                $(dataInput).val(recentValue - 1)

                // Dam submit la form
                $(dataInput).submit()

            } else {
                $(dataButton).attr("disabled", true)
            }

            return false;
        }

        if ($(this).attr("data-action") == "manual_quantity") {
            $(this).keypress(function (e) {
                // Dam submit la form
                e.which == 13 && $(this).submit()
            });
            return false;
        }
    })
})


const confirmationCheckBoxes = document.querySelectorAll('.confirmation__checkbox input[type="checkbox"]')
const checkoutButton = document.querySelector("#purchase-button")
const gatewayForm = document.querySelector(".gateway")

confirmationCheckBoxes?.forEach((checkbox) => {
    checkbox.addEventListener('click', (e) => {
        const areAllChecked = [...confirmationCheckBoxes].every(checkbox => checkbox.checked)
        checkoutButton.disabled = !areAllChecked
    })
})

const paymentGateways = document.querySelectorAll(".checkout__gateways--gateway input[type='radio']")

paymentGateways?.forEach((gateway) => {
    gateway.addEventListener('click', (e) => {
        const selectedGateway = e.target.id
        if (selectedGateway == "crypto") {
            checkoutButton.setAttribute("data-modal-toggler", "crypto")
            return
        }
        checkoutButton.removeAttribute("data-modal-toggler")
    })
})

gatewayForm?.addEventListener('submit', (e) => {

    const selectedGateway = document.querySelector(".checkout__gateways--gateway input[type='radio']:checked").id

    if (selectedGateway == "crypto") {

        document.querySelector("[data-modal-type='crypto']").showModal()
        removeLoadingModal()

        e.preventDefault()
        e.stopImmediatePropagation()
        return
    }
})