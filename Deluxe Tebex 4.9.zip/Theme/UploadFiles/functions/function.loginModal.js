// heck if steam is enabled, if is not the avatar will change while typing in the input from login modal

{% if config("serverType") == "Minecraft" %}
document.querySelector("#mc_IGN_INPUT").addEventListener("keyup", function (e) {
    if (this.value.length > 1) {
        const skin = this.value.replaceAll(`{{ config("bedrockPrefix") }}`, "")
        document.querySelector("#avatar_MC").src = `https://minotar.net/avatar/${skin}/32`
        return
    }
    document.querySelector("#avatar_MC").src = `https://minotar.net/avatar/MHF_Question/32`
})
{% endif %}

const clickableCategories = document.querySelectorAll("[data-login-category]")
let lastClickedCategoryLink

clickableCategories?.forEach(category => {
    category.addEventListener("click", function (e) {
        e.preventDefault()
        lastClickedCategoryLink = e.target.getAttribute("href")
    })
});

const bedrockUser = document.querySelector("#bedrockIGN")

$(function () {
    $('.login-panel form').submit(function (e) {
        e.preventDefault();
        $("#mc_IGN_INPUT").addClass("login-error")

        if ($("#mc_IGN_INPUT").val().length >= 3) {
            let oldValue = $("#mc_IGN_INPUT").val()

            if (bedrockUser?.checked && oldValue.includes(`{{ config("bedrockPrefix") }}`) === false) {
                $("#mc_IGN_INPUT").val(`{{ config("bedrockPrefix") }}${oldValue}`)
            }

            $(".login-loader").show()
            $("#mc_IGN_INPUT").removeClass("login-error")

            $.ajax({
                url: '/login',
                data: $(this).serialize(),
                method: 'POST',
            })
                .done(function (resp) {
                    $(".loading__animated").hide();
                    $("#successAnimation").show();
                    setTimeout(() => {
                        if (lastClickedCategoryLink) {
                            window.location = lastClickedCategoryLink
                            return
                        }
                        location.reload()
                    }, 1000);
                });

        }
    });
}); 